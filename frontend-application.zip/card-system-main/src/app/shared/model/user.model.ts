export class User {
  id?: number | undefined | null
  email?: string | undefined | null
  first_name?: string | undefined | null
  last_name?: string | undefined | null
  username?: string | undefined | null
  password?: string | undefined | null
}
